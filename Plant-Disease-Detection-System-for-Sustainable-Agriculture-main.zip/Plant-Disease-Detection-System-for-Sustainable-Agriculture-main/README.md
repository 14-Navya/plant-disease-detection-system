# Plant-Disease-Detection-System-for-Sustainable-Agriculture P2
The Plant Disease Detection System for Sustainable Agriculture leverages machine learning to identify and classify plant diseases,
